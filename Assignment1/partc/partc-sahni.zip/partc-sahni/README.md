# hw1_partb

Solution of HW1 part B
