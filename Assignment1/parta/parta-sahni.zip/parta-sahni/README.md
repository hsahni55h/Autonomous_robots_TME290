# tme290_assignment1

Homework 1 solution
