#include <iostream>

int32_t main(int32_t argc, char **argv) {
  std::cout << "Hello world = 1" << std::endl;
  return 0;
}

